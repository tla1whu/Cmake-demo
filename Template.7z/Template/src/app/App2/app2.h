#ifdef __cplusplus
extern "C"
{
#endif

#include "head.h"

uint8 Apptest2(void);
uint8 AppFunc2(void);

#ifdef __cplusplus
}
#endif
