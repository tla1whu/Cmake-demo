#include "app2.h"

uint8 Apptest2(void)
{
    return 2;
}