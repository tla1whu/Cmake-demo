#include "app2.h"

uint8 AppFunc2(void)
{
    uint8 u8result = 0;
    u8result = Apptest2();
    return u8result;
}