
#ifdef __cplusplus
extern "C"
{
#endif

#include "head.h"

uint8 Apptest(void);
uint8 AppFunc(void);


#ifdef __cplusplus
}
#endif
