#include "app.h"

uint8 AppFunc(void)
{

    uint8 u8result = 0;
    u8result = Apptest();
    return u8result;
}