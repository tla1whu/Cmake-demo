#include "port.h"


uint8 SetPort(uint8 port)
{
    return port;
}
