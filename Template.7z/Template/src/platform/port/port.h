#ifdef __cplusplus
extern "C"
{
#endif

#include "head.h"


uint8 SetPort(uint8 port);

#ifdef __cplusplus
}
#endif
