typedef unsigned char uint8;
typedef signed char sint8;
typedef unsigned int uint32;
typedef signed int sint32;


#define TRUE    1u
#define FALSE   0u
