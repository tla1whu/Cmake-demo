#ifdef __cplusplus
extern "C"
{
#endif


#include "head.h"


uint8 Dio_Write(uint8 port);
uint8 Dio_setport(void);

#ifdef __cplusplus
}
#endif
