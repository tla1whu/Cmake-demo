cmake -G "Visual Studio 12" ..\src
cmake --build .